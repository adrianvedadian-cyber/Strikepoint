STRIKEPOINT: TRAINING GROUNDS
================================

An original HTML5 / WebGL military-style training FPS.

WHAT'S INCLUDED
- 3D WebGL arena
- Desktop mouse + keyboard controls
- Mobile touch controls
- 3 weapons: assault rifle, SMG, marksman rifle
- Shooting, recoil, ammo, reloads, sprint, jump
- Training-drone enemies
- Health and damage
- Hitmarkers and headshot bonus damage
- Score system
- Two capture objectives
- Minimap
- Muzzle flash, tracers, simple synthesized sound
- High / Performance quality toggle
- Pause / restart menu
- No blood or gore
- No copyrighted Call of Duty assets, names, maps, music, or logos

HOW TO RUN
1. Open index.html in a modern browser.
2. The game starts immediately with no main menu.
3. Change graphics quality anytime using the QUALITY button in the top-right corner.
4. Internet is required the first time because Three.js is loaded from a CDN.
5. For best results, serve the folder over HTTPS using a static site host.

DESKTOP CONTROLS
WASD       Move
Mouse      Look
Left click Fire
R          Reload
Shift      Sprint
Space      Jump
1 / 2 / 3  Select weapon
E          Interact / capture
Esc        Pause

MOBILE CONTROLS
Left stick     Move
Drag right     Look
FIRE           Shoot
R              Reload
SWAP           Cycle weapon
JUMP           Jump
USE            Capture objective

OBJECTIVE
1. Disable 5 training drones.
2. Capture Alpha and Bravo.
3. Continue in free training mode for score.

This is an original game and is not affiliated with Activision or Call of Duty.
